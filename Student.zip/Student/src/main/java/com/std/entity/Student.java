package com.std.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="StudentApplication")
public class Student {
	@Id
	private int stdId;
	private String stdName;
	private double stdMark;
	public Student() {
	}
	public Student(int stdId, String stdName, double stdMark) {
		this.stdId = stdId;
		this.stdName = stdName;
		this.stdMark = stdMark;
	}
	public int getStdId() {
		return stdId;
	}
	public void setStdId(int stdId) {
		this.stdId = stdId;
	}
	public String getStdName() {
		return stdName;
	}
	public void setStdName(String stdName) {
		this.stdName = stdName;
	}
	public double getStdMark() {
		return stdMark;
	}
	public void setStdMark(double stdMark) {
		this.stdMark = stdMark;
	}
}

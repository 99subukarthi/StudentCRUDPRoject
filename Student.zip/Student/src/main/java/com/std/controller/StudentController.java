package com.std.controller;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.std.dto.StudentDTO;
import com.std.entity.Student;
import com.std.service.StudentService;

@RestController
@CrossOrigin("http://localhost:4500")
@RequestMapping("/std/register")
public class StudentController {
	
	@Autowired
	StudentService stdService;
	
	@PostMapping("/save")
	public String stdSave(@RequestBody StudentDTO dto) {
		return stdService.saveStudent(dto);
	}
	
	
	@GetMapping("/search")
	public List<StudentDTO> getAllStudent(){
		List<Student> std= stdService.getAllStudent();
		List<StudentDTO> stdDTOlist= new ArrayList<StudentDTO>();
		for(Student s:std) {
		StudentDTO dto=new StudentDTO();
		dto.setStdId(s.getStdId());
		dto.setStdName(s.getStdName());
		dto.setStdMark(s.getStdMark());
		stdDTOlist.add(dto);
		}
		return stdDTOlist;
	}
	
	
	@DeleteMapping("/remove/{id}")
	public String stdRemove(@PathVariable int id) {
		return stdService.deleteStudent(id);	
	}
	
	@PutMapping("/update")
	public String stdUpdate(@RequestBody StudentDTO dto) {
		return stdService.updateStudent(dto);
	}
}

package com.std.serviceimpl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.std.dto.StudentDTO;
import com.std.entity.Student;
import com.std.repo.StudentRepo;
import com.std.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentRepo stdRepo;

	@Override
	public List<Student> getAllStudent() {
		
		return stdRepo.findAll();
	}
	
	
	@Override
	public String deleteStudent(int id) {
		Student std=stdRepo.findById(id).orElse(null);
		stdRepo.delete(std);
		Student stdres=stdRepo.findById(id).orElse(null);
		if(stdres==null) {
		return "Student Id: "+std.getStdId()+"\n"
				+ "Student Name:"+std.getStdName()+"\n"
						+ "The Above Student Details are permanently Removed.....";
		}
		else {
			return "Oops something went worng try after some more times";
		}
	}
	
	
	@Override
	public String saveStudent(StudentDTO stdDTO) {
		Student std=new Student();
		std.setStdId(stdDTO.getStdId());
		std.setStdName(stdDTO.getStdName());
		std.setStdMark(stdDTO.getStdMark());
		stdRepo.save(std);
		Student stdres=stdRepo.findById(stdDTO.getStdId()).orElse(null);
		if(stdres==null) {
			return "Student Registeration is failed!!!!";
		}
		else {
			return "Student "+stdres.getStdName()+" is Successfully Saved...";
		}
	}
	

	@Override
	public String updateStudent(StudentDTO stdDTO) {
		Student std=stdRepo.findById(stdDTO.getStdId()).orElse(null);
		if(std!=null) {
			std.setStdMark(stdDTO.getStdMark());
			std.setStdName(stdDTO.getStdName());
			return "Student "+std.getStdName()+" is Successfully Updated...";
		}
		else {
			return "Updation Failed!!!!!";
		}
	}

}

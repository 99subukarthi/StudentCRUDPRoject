package com.std.dto;

public class StudentDTO {
private int stdId;
private String stdName;
private double stdMark;
public StudentDTO() {
	super();
}
public StudentDTO(int stdId, String stdName, double stdMark) {
	super();
	this.stdId = stdId;
	this.stdName = stdName;
	this.stdMark = stdMark;
}
public int getStdId() {
	return stdId;
}
public void setStdId(int stdId) {
	this.stdId = stdId;
}
public String getStdName() {
	return stdName;
}
public void setStdName(String stdName) {
	this.stdName = stdName;
}
public double getStdMark() {
	return stdMark;
}
public void setStdMark(double stdMark) {
	this.stdMark = stdMark;
}
}

package com.std.service;

import java.util.List;

import com.std.dto.StudentDTO;
import com.std.entity.Student;

public interface StudentService {
	public String saveStudent(StudentDTO std);
	public List<Student> getAllStudent();
	public String deleteStudent(int id);
	public String updateStudent(StudentDTO std);
}

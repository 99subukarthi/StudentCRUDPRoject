import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Student } from './student';
import { HttpClient } from '@angular/common/http';
import { FormGroup } from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit{
  baseUrl = 'http://10.1.17.47:7000/std/register';
  saveUrl = '/save';
  searchUrl = '/search';
  updateUrl = '/update';
  deleteUrl = '/remove';
  studentDetails!: Student[];
  std: Student = new Student();
  update=false;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.getAllStudents();
  }

  public saveStudent(): void {
    debugger
    if(this.update){
      debugger
      this.http.put(`${this.baseUrl}${this.updateUrl}`, this.std, { responseType: 'text' }).subscribe(
        (response: string) => {
         alert(response);
          this.getAllStudents(); 
        },
        error => {
         alert(`Error saving student:${error}`);
        }
      );
  }
  else{
    debugger
    this.http.post(`${this.baseUrl}${this.saveUrl}`, this.std, { responseType: 'text' }).subscribe(
      (response: string) => {
       alert(response);
        this.getAllStudents(); 
      },
      error => {
       alert(`Error saving student:${error}`);
      }
    );
  }
}

  public getAllStudents(): void {
    this.http.get<Student[]>(`${this.baseUrl}${this.searchUrl}`, { responseType: 'json' }).subscribe(
      (response: Student[]) => {
        this.studentDetails = response;
      },
      error => {
        console.error('Error fetching students:', error);
        this.studentDetails = [];
      }
    );
  }

  public deleteStudent(id:number):void{
    this.http.delete(`${this.baseUrl}${this.deleteUrl}/${id}`,{responseType:'text'}).subscribe(
      (response:any)=>{
        alert(response);
      this.getAllStudents();
      },
      error=>{
        console.log(error);
      }
    )
  }

  public updateStudent(std:Student):any{
    this.std = std;
      // this.std.stdId=std.stdId;
      // this.std.stdName=std.stdName;
      // this.std.stdMark=std.stdMark;
    this.update=true;
  }

}

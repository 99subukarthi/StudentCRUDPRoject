export class Student {
stdId!:number;
stdName!:String;
stdMark!:number;
}
